(function($) {
    $("section .container .sub-container-1").css({
        marginLeft: -$("section .container").offset().left - parseInt($("section .container").css("padding-left")),
        width: $(document).width()
    });
    $(window).resize(function() {
        $("section .container .sub-container-1").css({
            marginLeft: -$("section .container").offset().left - parseInt($("section .container").css("padding-left")),
            width: $(document).width()
        });
    });

    $.fn.GApageview = function(url, title) {
        ga('send', 'pageview', url, title);
    };
    $.fn.GAevent = function(category, event, label, counter) {
        if (typeof counter !== "undefined") {
            ga('send', 'event', category, event, label, counter);
        } else if (typeof label !== "undefined") {
            ga('seng', 'event', category, event, label);
        } else {
            ga('send', 'event', category, event);
        }
    };
})(jQuery);
