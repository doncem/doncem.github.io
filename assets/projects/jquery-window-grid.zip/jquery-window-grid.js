/**
 * Set wrapper to window size with required gaps
 * @param {int} gap
 * @returns {Object} jQuery selected object
 */
$.fn.sizeWrapper = function(gap) {
    $(this).css({
        width: $(window).width(),
        height: $(window).height() - parseInt($("body").css("padding-top")) + 1,// couldn't think of any border. there is a nav one, but..
        paddingLeft: gap,
        paddingTop: gap
    });

    $(this).click(function(e) {
        if ($(e.target).hasClass($(this).attr("class"))) {
            $(this).children().each(function(i, e) { $(e).hide(); });
            $(this).hide("fast");
        }
    });

    return $(this);
};

/**
 * Enable/disable scrollbar in the browser
 * @param {Boolean} enable
 * @returns {void}
 */
$.fn.toggleBrowserScrollbar = function(enable) {
    var scrollPosition = [
        self.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft,
        self.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop
    ];
    var html = $("body");

    if (enable) {
        scrollPosition = html.data("scroll-position");
        html.css("overflow", html.data("previous-overflow"));
        window.scrollTo(scrollPosition[0], scrollPosition[1]);
    } else {
        html.data("scroll-position", scrollPosition);
        html.data("previous-overflow", html.css("overflow"));
        html.css("overflow", "hidden");
        window.scrollTo(scrollPosition[0], scrollPosition[1]);
    }
};

/**
 * jQuery Window Grid Experiment
 * @returns {void}
 */
var jqueryWindowGrid = function() {
    var c = $("#jquery-window-grid-container"),
        element = "<div id=\"grid-element-\" class=\"grid-element\" data-x=\"\" data-y=\"\"></div>",
        gap = 4,
        activeColour = "#012345",
        colour = "#543210";

    var calculateSize = function(wSize, k) {
        return Math.floor((wSize - gap) / k - gap - 2 * parseInt($(".grid-element").first().css("border-width")));
    };

    var calculateMax = function(wSize) {
        return Math.floor((wSize - gap) / (3 + gap));
    };

    /**
     * Add element to the grid
     * @param {string} type Where to add element: 'prepend' or 'append'
     * @param {int} w New width
     * @param {int} h New height
     * @param {int} t Position from top
     * @param {int} l Position from left
     */
    var addE = function(type, w, h, t, l) {
        if (type === "prepend") {
            c.prepend(element);
        } else {
            c.append(element);
        }

        $("#grid-element-").attr("id", "grid-element-" + xCurrent + "-" + yCurrent)
                           .attr("data-x", xCurrent)
                           .attr("data-y", yCurrent)
                           .animate({
                               width:w + 2,
                               height:h + 2,
                               top:t,
                               left:l,
                               backgroundColor:activeColour
                           }, "fast");
    };

    var close = function() {
        c.children("div").each(function(i, e) {
            setTimeout(function(e) { $(e).fadeOut("fast"); }, 400);
        }).parent().hide("slow");
        $().toggleBrowserScrollbar(true);
    };

    var moveLeft = function() {
        xCurrent--;
        $("#grid-element-" + (xCurrent + 1) + "-" + yCurrent).animate({backgroundColor:colour}, "fast");

        if ($("#grid-element-" + xCurrent + "-" + yCurrent).length > 0) {
            $("#grid-element-" + xCurrent + "-" + yCurrent).animate({backgroundColor:activeColour}, "fast");
        } else {
            var column = $(".grid-element[data-x='" + xCurrent + "']"),
                line = $(".grid-element[data-y='" + yCurrent + "']");

            if (column.length > 0) {
                addE("prepend", line.first().width(), line.first().height(), parseInt(line.first().css("top")), parseInt(column.first().css("left")));
            } else {
                if (line.length < xMax) {
                    minX--;
                    var newX = calculateSize(c.width(), maxX - minX + 1);
                    $(".grid-element").each(function(i, e) {
                        $(e).animate({
                            left:(parseInt($(e).attr("data-x")) - xCurrent + 1) * gap + (parseInt($(e).attr("data-x")) - xCurrent) * (2 * parseInt($(".grid-element").first().css("border-width")) + newX),
                            width:newX
                        }, "fast");
                    });
                    addE("prepend", newX, line.first().height(), line.first().css("top"), gap);
                } else {
                    $(line[line.length - 1]).animate({backgroundColor:activeColour}, "fast");
                    xCurrent = parseInt($(line[line.length - 1]).attr("data-x"));
                }
            }
        }
    };

    var moveUp = function() {
        yCurrent--;
        $("#grid-element-" + xCurrent + "-" + (yCurrent + 1)).animate({backgroundColor:colour}, "fast");

        if ($("#grid-element-" + xCurrent + "-" + yCurrent).length > 0) {
            $("#grid-element-" + xCurrent + "-" + yCurrent).animate({backgroundColor:activeColour}, "fast");
        } else {
            var column = $(".grid-element[data-x='" + xCurrent + "']"),
                line = $(".grid-element[data-y='" + yCurrent + "']");

            if (line.length > 0) {
                addE("prepend", line.first().width(), line.first().height(), parseInt(line.first().css("top")), parseInt(column.first().css("left")));
            } else {
                if (column.length < yMax) {
                    minY--;
                    var newY = calculateSize(c.height(), maxY - minY + 1);
                    $(".grid-element").each(function(i, e) {
                        $(e).animate({
                            top:(parseInt($(e).attr("data-y")) - yCurrent + 1) * gap + (parseInt($(e).attr("data-y")) - yCurrent) * (2 * parseInt($(".grid-element").first().css("border-width")) + newY),
                            height:newY
                        }, "fast");
                    });
                    addE("prepend", column.first().width(), newY, gap, parseInt(column.first().css("left")));
                } else {
                    $(column[column.length - 1]).animate({backgroundColor:activeColour}, "fast");
                    yCurrent = parseInt($(column[column.length - 1]).attr("data-y"));
                }
            }
        }
    };

    var moveRight = function() {
        xCurrent++;
        $("#grid-element-" + (xCurrent - 1) + "-" + yCurrent).animate({backgroundColor:colour}, "fast");

        if ($("#grid-element-" + xCurrent + "-" + yCurrent).length > 0) {
            $("#grid-element-" + xCurrent + "-" + yCurrent).animate({backgroundColor:activeColour}, "fast");
        } else {
            var column = $(".grid-element[data-x='" + xCurrent + "']"),
                line = $(".grid-element[data-y='" + yCurrent + "']");

            if (column.length > 0) {
                addE("append", line.first().width(), line.first().height(), parseInt(line.first().css("top")), parseInt(column.first().css("left")));
            } else {
                if (line.length < xMax) {
                    maxX++;
                    var newX = calculateSize(c.width(), maxX - minX + 1);
                    $(".grid-element").each(function(i, e) {
                        $(e).animate({
                            left:(maxX - minX - xCurrent + parseInt($(e).attr("data-x")) + 1) * gap + (maxX - minX - xCurrent + parseInt($(e).attr("data-x"))) * (2 * parseInt($(".grid-element").first().css("border-width")) + newX),
                            width:newX
                        }, "fast");
                    });
                    addE("append", newX, line.first().height(), line.first().css("top"), (maxX - minX + 1) * gap + (maxX - minX) * (2 * parseInt($(".grid-element").first().css("border-width")) + newX));
                } else {
                    $(line[0]).animate({backgroundColor:activeColour}, "fast");
                    xCurrent = parseInt($(line[0]).attr("data-x"));
                }
            }
        }
    };

    var moveDown = function() {
        yCurrent++;
        $("#grid-element-" + xCurrent + "-" + (yCurrent - 1)).animate({backgroundColor:colour}, "fast");

        if ($("#grid-element-" + xCurrent + "-" + yCurrent).length > 0) {
            $("#grid-element-" + xCurrent + "-" + yCurrent).animate({backgroundColor:activeColour}, "fast");
        } else {
            var column = $(".grid-element[data-x='" + xCurrent + "']"),
                line = $(".grid-element[data-y='" + yCurrent + "']");

            if (line.length > 0) {
                addE("append", line.first().width(), line.first().height(), parseInt(line.first().css("top")), parseInt(column.first().css("left")));
            } else {
                if (column.length < yMax) {
                    maxY++;
                    var newY = calculateSize(c.height(), maxY - minY + 1);
                    $(".grid-element").each(function(i, e) {
                        $(e).animate({
                            top:(maxY - minY - yCurrent + parseInt($(e).attr("data-y")) + 1) * gap + (maxY - minY - yCurrent + parseInt($(e).attr("data-y"))) * (2 * parseInt($(".grid-element").first().css("border-width")) + newY),
                            height:newY
                        }, "fast");
                    });
                    addE("append", column.first().width(), newY, (maxY - minY + 1) * gap + (maxY - minY) * (2 * parseInt($(".grid-element").first().css("border-width")) + newY), column.first().css("left"));
                } else {
                    $(column[0]).animate({backgrounColor:activeColour}, "fast");
                    yCurrent = parseInt($(column[0]).attr("data-y"));
                }
            }
        }
    };

    $().toggleBrowserScrollbar(false);

    if (c.children("div").length > 1) {
        c.show("slow").children("div").each(function(i, e) {
            setTimeout(function(e) { $(e).fadeIn("fast"); }, 400);
        });
    } else {
        var xCurrent = 1,
            yCurrent = 1,
            xMax = calculateMax($(window).width()),
            yMax = calculateMax($(window).height() - parseInt($("body").css("padding-top"))),
            maxX = 1,
            maxY = 1,
            minX = 1,
            minY = 1;
        c.sizeWrapper(gap).show("slow", function() {
            $(this).children("div").css({
                left: gap,
                top: gap,
                width: c.width() - (gap + 1),
                height: c.height() - (gap + 1),
                backgroundColor: activeColour
            }).fadeIn("fast");
        });
    }

    var doKeyUp = function(key) {
        switch(key) {
            case 27:
                close();
                break;
            case 37:
                moveLeft();
                break;
            case 38:
                moveUp();
                break;
            case 39:
                moveRight();
                break;
            case 40:
                moveDown();
                break;
        }
    };

    var timeout;
    $(window).keyup(function(e) {
        e.preventDefault();
        timeout = setTimeout(doKeyUp, timeout !== undefined ? 100 : 0, e.which);
    });

    $(window).resize(function() {
        xMax = calculateMax(c.width());
        yMax = calculateMax(c.height());
        var newX = calculateSize(c.width(), maxX - minX + 1),
            newY = calculateSize(c.height(), maxY - minY + 1);

        $(".grid-element").each(function(i, e) {
            $(e).animate({
                top:(parseInt($(e).attr("data-y")) - minY + 1) * gap + (parseInt($(e).attr("data-y")) - minY) * (2 * parseInt($(".grid-element").first().css("border-width")) + newY),
                left:(parseInt($(e).attr("data-X")) - minX + 1) * gap + (parseInt($(e).attr("data-x")) - minX) * (2 * parseInt($(".grid-element").first().css("border-width")) + newX),
                width:newX,
                height:newY
            }, "fast");
        });
    });
};

jqueryWindowGrid();
